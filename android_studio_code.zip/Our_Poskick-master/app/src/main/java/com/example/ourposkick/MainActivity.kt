package com.example.ourposkick

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ourposkick.HelmetActivity
import com.example.ourposkick.ParkingActivity  // Import the ParkingActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // '탑승 시작' 버튼 클릭 시 호출되는 메소드
    fun startHelmetActivity(view: View?) {
        val intent = Intent(this, HelmetActivity::class.java)
        startActivity(intent)
    }

    // '탑승 종료' 버튼 클릭 시 호출되는 메소드
    fun endRideActivity(view: View?) {
        val intent = Intent(this, ParkingActivity::class.java)
        startActivity(intent)
    }

}



