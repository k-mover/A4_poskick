package com.example.ourposkick

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class AcceptHelmetActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.accept_helmet) // 레이아웃 파일과 연결

        // ImageView 찾기
        val imageView = findViewById<ImageView>(R.id.imageViewAccepted)

        // Intent에서 바이트 배열로 이미지 데이터 받기
        val byteArray = intent.getByteArrayExtra("imageByteArray")
        if (byteArray != null) {
            // 바이트 배열에서 Bitmap 생성
            val bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            // ImageView에 Bitmap 설정
            imageView.setImageBitmap(bitmap)
        }
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, DrivingActivity::class.java)
            startActivity(intent)
            finish() // 현재 액티비티 종료
        }, 3000) // 3000밀리초, 즉 3초 후 실행

    }
}

