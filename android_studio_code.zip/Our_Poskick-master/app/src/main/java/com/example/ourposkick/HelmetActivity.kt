package com.example.ourposkick


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.io.DataOutputStream
import java.net.Socket

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch




class HelmetActivity : AppCompatActivity() {
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_helmet)


        val button: Button = findViewById(R.id.button3)
        button.setOnClickListener {
            coroutineScope.launch {
                connectToServer()
            }
        }
    }

    // 라즈베리 파이 카메라 작동 -> yolo 돌리게 하는 코드
    private suspend fun connectToServer() {
        withContext(Dispatchers.IO) { // 모든 네트워크 작업을 IO 스레드에서 실행
            try {
//                192.168.0.6는 rpi4 192.168.0.18은 rpi5주소
                val socket = Socket("192.168.0.20", 8998)  // 라즈베리 파이의 IP 주소와 포트
                val outputStream = DataOutputStream(socket.getOutputStream())

                val message = "1"
                outputStream.writeUTF(message)
                outputStream.flush()
                outputStream.close()
                socket.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            withContext(Dispatchers.Main) {
                // 네트워크 작업 완료 후 메인 스레드에서 UI 전환
                transitionToDetectingHelmet()
            }
        }
    }


// 데이터 받고 detecting_helmet으로 화면전환
    private fun transitionToDetectingHelmet() {
        // 화면 전환 로직
        val intent = Intent(this@HelmetActivity, HelmetDetecting::class.java)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        coroutineScope.cancel() // 액티비티 종료 시 코루틴 취소
    }


}
