package com.example.ourposkick

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DrivingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driving) // 레이아웃 파일과 연결
    }
}