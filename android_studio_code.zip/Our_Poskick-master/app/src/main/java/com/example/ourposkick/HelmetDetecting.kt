package com.example.ourposkick

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException

class HelmetDetecting : AppCompatActivity() {
    private lateinit var serverSocket: ServerSocket
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val port = 8997

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detecting_helmet)
        startServer()
        startHelmetDetection()
    }

    private fun startServer() {
        coroutineScope.launch {
            try {
                serverSocket = ServerSocket(port)  // 포트 8997에서 연결 수신
                serverSocket.soTimeout = 30000  // 30초 타임아웃 설정
                println("Server is running on port $port")
            } catch (e: IOException) {
                println("Error starting server: ${e.message}")
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@HelmetDetecting, "Failed to start server", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startHelmetDetection() {
        coroutineScope.launch {
            try {
                val clientSocket = serverSocket.accept()  // 클라이언트 연결 수락
                println("Connected to ${clientSocket.inetAddress.hostAddress}")
                handleClient(clientSocket)
            } catch (e: SocketTimeoutException) {
                println("Socket Timeout: ${e.message}")
            } catch (e: IOException) {
                println("Error connecting to client: ${e.message}")
            }
        }
    }

    private suspend fun handleClient(clientSocket: Socket) {
        val inputStream = withContext(Dispatchers.IO) {
            clientSocket.getInputStream()
        }
        val reader = BufferedReader(InputStreamReader(inputStream))
        val message = StringBuilder()
        var line: String?

        while (withContext(Dispatchers.IO) {
                reader.readLine()
            }.also { line = it } != null) {
            message.append(line)
        }

        println("Received from client: $message")

        withContext(Dispatchers.Main) {
            processData(message.toString())
        }

        withContext(Dispatchers.IO) {
            clientSocket.close()
        }  // 클라이언트 소켓 닫기
    }

    private fun processData(message: String) {
        val jsonObject = JSONObject(message)
        val imageString = jsonObject.getString("image")
        val confidence = jsonObject.getDouble("confidence")
        val bitmap = decodeBase64Image(imageString)
        showResult(bitmap, confidence)
    }

    private fun decodeBase64Image(encodedImage: String): Bitmap {
        val decodedString = Base64.decode(encodedImage, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
    }

    private fun showResult(bitmap: Bitmap, confidence: Double) {
        Log.d("HelmetDetection", "Confidence level: $confidence")
        val imageByteArray = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, imageByteArray)
        val byteArray = imageByteArray.toByteArray()

        val intent = Intent().apply {
            if (confidence >= 0.40) {
                setClass(this@HelmetDetecting, AcceptHelmetActivity::class.java)
            } else {
                setClass(this@HelmetDetecting, DeniedHelmetActivity::class.java)
            }
            putExtra("imageByteArray", byteArray) // 바이트 배열을 Intent에 추가
        }
        startActivity(intent)
    }



    override fun onDestroy() {
        super.onDestroy()
        stopServer()
    }

    private fun stopServer() {
        coroutineScope.launch {
            try {
                serverSocket.close()  // 서버 소켓 닫기
                println("Server socket closed")
            } catch (e: IOException) {
                println("Error closing server: ${e.message}")
            }
        }
        coroutineScope.cancel()
    }
}
