package com.example.ourposkick

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DrivingHelmetWarning : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.driving_helmet_warning) // 레이아웃 파일과 연결
    }
}