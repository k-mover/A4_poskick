package com.example.ourposkick

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class DeniedHelmetActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.denied_helmet) // 레이아웃 파일과 연결

        // ImageView 찾기
        val imageView = findViewById<ImageView>(R.id.imageViewDenied)

        // Intent에서 바이트 배열로 이미지 데이터 받기
        val byteArray = intent.getByteArrayExtra("imageByteArray")
        if (byteArray != null) {
            // 바이트 배열에서 Bitmap 생성
            val bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
            // ImageView에 Bitmap 설정
            imageView.setImageBitmap(bitmap)
        }


    }
}
